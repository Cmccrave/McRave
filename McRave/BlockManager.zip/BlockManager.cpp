#include "McRave.h"

void BlockTrackerClass::update()
{
	updateBlocks();
}

void BlockTrackerClass::updateBlocks()
{
	// For reference: https://imgur.com/a/I6IwH

	// Currently missing features:
	// - Mirroring isn't fully implemented
	// - Counting of how many of each type of block
	// - Defensive blocks
	// - Blocks for areas other than main
	// - Low variations so usually unoptimized

	Area const * mainArea = theMap.GetArea(Terrain().getPlayerStartingTilePosition());
	set<TilePosition> mainTiles;

	for (int x = 0; x <= Broodwar->mapWidth(); x++)
	{
		for (int y = 0; y <= Broodwar->mapHeight(); y++)
		{
			if (!TilePosition(x, y).isValid()) continue;
			if (!theMap.GetArea(TilePosition(x, y))) continue;
			if (theMap.GetArea(TilePosition(x, y)) == mainArea) mainTiles.insert(TilePosition(x, y));
		}
	}

	// Mirror? (Gate on right)
	bool mirrorHorizontal = false;
	bool mirrorVertical = false;
	if (Position(Terrain().getFirstChoke()).x > Terrain().getPlayerStartingPosition().x) mirrorHorizontal = true;
	if (Position(Terrain().getFirstChoke()).y > Terrain().getPlayerStartingPosition().y) mirrorVertical = true;

	// Find first chunk position
	if (Broodwar->getFrameCount() == 0)
	{
		double distA = DBL_MAX;
		TilePosition tile = Terrain().getPlayerStartingTilePosition();
		for (auto tile : mainTiles)
		{
			if (!canAddBlock(tile, 6, 8)) continue;
			Position blockCenter = Position(TilePosition(tile.x + 3, tile.y + 4));

			double distB = pow(blockCenter.getDistance(Terrain().getPlayerStartingPosition()), 2.0) * blockCenter.getDistance(Position(Terrain().getFirstChoke()));
			if (distB < distA)
			{
				distA = distB;
				best = tile;
			}
		}
		insertMediumBlock(best, mirrorHorizontal, mirrorVertical);

		if (Broodwar->self()->getRace() == Races::Protoss)
		{
			for (auto tile : mainTiles)
				if (canAddBlock(tile, 6, 8)) insertMediumBlock(tile, mirrorHorizontal, mirrorVertical);
			for (auto tile : mainTiles)
				if (canAddBlock(tile, 4, 5)) insertSmallBlock(tile, mirrorHorizontal, mirrorVertical);
		}
		else if (Broodwar->self()->getRace() == Races::Terran)
		{
			for (auto tile : mainTiles)
				if (canAddBlock(tile, 6, 8)) insertMediumBlock(tile, mirrorHorizontal, mirrorVertical);
			for (auto tile : mainTiles)
				if (canAddBlock(tile, 3, 4)) insertSmallBlock(tile, mirrorHorizontal, mirrorVertical);
		}
	}

	for (auto tile : smallPosition)
		Broodwar->drawBoxMap(Position(tile), Position(tile + TilePosition(2, 2)), Broodwar->self()->getColor());
	for (auto tile : mediumPosition)
		Broodwar->drawBoxMap(Position(tile), Position(tile + TilePosition(3, 2)), Broodwar->self()->getColor());
	for (auto tile : largePosition)
		Broodwar->drawBoxMap(Position(tile), Position(tile + TilePosition(4, 3)), Broodwar->self()->getColor());
}

bool BlockTrackerClass::canAddBlock(TilePosition here, int width, int height)
{
	// Check if a block of specified size would overlap any bases, resources or other blocks
	for (int x = here.x - 1; x < here.x + width + 1; x++)
	{
		for (int y = here.y - 1; y < here.y + height + 1; y++)
		{
			if (!TilePosition(x, y).isValid()) return false;
			if (!theMap.GetTile(TilePosition(x, y)).Buildable()) return false;				// BWEM call
			if (Grids().getResourceGrid(x, y) > 0) return false;							// If you don't have anything to prevent building near minerals, leave this commented out
			if (Blocks().overlapsBlocks(TilePosition(x, y))) return false;
			if (Terrain().overlapsBases(TilePosition(x, y))) return false;					// Function that iterates all bases to see if they overlap
			if (Terrain().overlapsNeutrals(TilePosition(x, y))) return false;				// Function that iterates all minerals and geysers to see if they overlap
		}
	}
	return true;
}

bool BlockTrackerClass::overlapsBlocks(TilePosition here)
{
	for (auto &b : blocks)
	{
		Block& block = b.second;
		if (here.x >= block.tile().x && here.x < block.tile().x + block.width() && here.y >= block.tile().y && here.y < block.tile().y + block.height()) return true;
	}
	return false;
}

void BlockTrackerClass::insertSmallBlock(TilePosition here, bool mirrorHorizontal, bool mirrorVertical)
{
	if (Broodwar->self()->getRace() == Races::Protoss)
	{
		blocks[here] = Block(4, 5, here);
		if (mirrorHorizontal)
		{
			smallPosition.insert(here);
			smallPosition.insert(here + TilePosition(2, 0));
			largePosition.insert(here + TilePosition(0, 2));
		}
		else
		{
			smallPosition.insert(here + TilePosition(0, 3));
			smallPosition.insert(here + TilePosition(2, 3));
			largePosition.insert(here);
		}
	}
	else if (Broodwar->self()->getRace() == Races::Terran)
	{
		blocks[here] = Block(3, 4, here);
		mediumPosition.insert(here);		
		mediumPosition.insert(here + TilePosition(0, 2));
	}
}

void BlockTrackerClass::insertMediumBlock(TilePosition here, bool mirrorHorizontal, bool mirrorVertical)
{
	if (Broodwar->self()->getRace() == Races::Protoss)
	{
		blocks[here] = Block(6, 8, here);
		mediumPosition.insert(here + TilePosition(0, 6));
		mediumPosition.insert(here + TilePosition(3, 6));

		if (mirrorHorizontal)
		{
			smallPosition.insert(here);
			smallPosition.insert(here + TilePosition(0, 2));
			smallPosition.insert(here + TilePosition(0, 4));
			largePosition.insert(here + TilePosition(2, 0));
			largePosition.insert(here + TilePosition(2, 3));
		}
		else
		{
			smallPosition.insert(here + TilePosition(4, 0));
			smallPosition.insert(here + TilePosition(4, 2));
			smallPosition.insert(here + TilePosition(4, 4));
			largePosition.insert(here);
			largePosition.insert(here + TilePosition(0, 3));
		}
	}
	else if (Broodwar->self()->getRace() == Races::Terran)
	{
		blocks[here] = Block(6, 8, here);
		smallPosition.insert(here + TilePosition(4, 1));
		smallPosition.insert(here + TilePosition(4, 4));
		mediumPosition.insert(here + TilePosition(0, 6));
		mediumPosition.insert(here + TilePosition(3, 6));
		largePosition.insert(here);
		largePosition.insert(here + TilePosition(0, 3));
	}
}

void BlockTrackerClass::insertLargeBlock(TilePosition here, bool mirrorHorizontal, bool mirrorVertical)
{

}